#!/bin/bash
/usr/bin/systemctl start tftp > /dev/null 2>&1
##
##
